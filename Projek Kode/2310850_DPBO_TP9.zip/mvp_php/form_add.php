<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    crossorigin="anonymous" />
  <title>Tambah Mahasiswa</title>
</head>

<body>
  <div class="container my-5">
    <h3 class="text-center mb-4">Tambah Data Mahasiswa</h3>
    <form action="index_request.php" method="POST">
      <input type="hidden" name="aksi" value="add">
      <div class="form-group">
        <label>NIM</label>
        <input type="text" class="form-control" name="nim" required>
      </div>
      <div class="form-group">
        <label>Nama</label>
        <input type="text" class="form-control" name="nama" required>
      </div>
      <div class="form-group">
        <label>Tempat Lahir</label>
        <input type="text" class="form-control" name="tempat" required>
      </div>
      <div class="form-group">
        <label>Tanggal Lahir</label>
        <input type="date" class="form-control" name="tl" required>
      </div>
      <div class="form-group">
        <label>Gender</label>
        <select class="form-control" name="gender" required>
          <option value="Laki-laki">Laki-laki</option>
          <option value="Perempuan">Perempuan</option>
        </select>
      </div>
      <div class="form-group">
        <label>Email</label>
        <input type="email" class="form-control" name="email" required>
      </div>
      <div class="form-group">
        <label>Telepon</label>
        <input type="text" class="form-control" name="telp" required>
      </div>
      <button type="submit" name="submit" class="btn btn-primary">Tambah</button>
      <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
  </div>
</body>

</html>
