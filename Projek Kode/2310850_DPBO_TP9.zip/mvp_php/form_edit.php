<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Mahasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <h3 class="text-center mb-4">Edit Data Mahasiswa</h3>

    <?php
    include("presenter/ProsesMahasiswa.php");

    $proses = new ProsesMahasiswa();
    $proses->prosesDataMahasiswa();

    $id = $_GET['id'];
    $data = null;

    // cari data mahasiswa berdasarkan id
    for ($i = 0; $i < $proses->getSize(); $i++) {
        if ($proses->getId($i) == $id) {
            $data = [
                'id' => $proses->getId($i),
                'nim' => $proses->getNim($i),
                'nama' => $proses->getNama($i),
                'tempat' => $proses->getTempat($i),
                'tl' => $proses->getTl($i),
                'gender' => $proses->getGender($i),
                'email' => $proses->getEmail($i),
                'telp' => $proses->getTelp($i)
            ];
            break;
        }
    }
    ?>

    <?php if ($data): ?>
    <form action="index_request.php" method="post" class="border p-4 bg-white shadow-sm rounded">
        <input type="hidden" name="aksi" value="edit">
        <input type="hidden" name="id" value="<?= $data['id'] ?>">

        <div class="mb-3">
            <label for="nim" class="form-label">NIM</label>
            <input type="text" class="form-control" id="nim" name="nim" value="<?= $data['nim'] ?>" required>
        </div>

        <div class="mb-3">
            <label for="nama" class="form-label">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?= $data['nama'] ?>" required>
        </div>

        <div class="mb-3">
            <label for="tempat" class="form-label">Tempat Lahir</label>
            <input type="text" class="form-control" id="tempat" name="tempat" value="<?= $data['tempat'] ?>" required>
        </div>

        <div class="mb-3">
            <label for="tl" class="form-label">Tanggal Lahir</label>
            <input type="date" class="form-control" id="tl" name="tl" value="<?= $data['tl'] ?>" required>
        </div>

        <div class="mb-3">
            <label for="gender" class="form-label">Gender</label>
            <select class="form-control" id="gender" name="gender" required>
                <option value="Laki-laki" <?= $data['gender'] == 'Laki-laki' ? 'selected' : '' ?>>Laki-laki</option>
                <option value="Perempuan" <?= $data['gender'] == 'Perempuan' ? 'selected' : '' ?>>Perempuan</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?= $data['email'] ?>" required>
        </div>

        <div class="mb-3">
            <label for="telp" class="form-label">No Telp</label>
            <input type="text" class="form-control" id="telp" name="telp" value="<?= $data['telp'] ?>" required>
        </div>

        <button type="submit" name="submit" class="btn btn-success">Simpan Perubahan</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
    <?php else: ?>
        <div class="alert alert-warning">Data tidak ditemukan.</div>
    <?php endif; ?>
</div>
</body>
</html>
