<?php
include("presenter/ProsesMahasiswa.php");

$proses = new ProsesMahasiswa();

if (isset($_POST['submit'])) {
    // ADD atau UPDATE
    $data = [
        'nim' => $_POST['nim'],
        'nama' => $_POST['nama'],
        'tempat' => $_POST['tempat'],
        'tl' => $_POST['tl'],
        'gender' => $_POST['gender'],
        'email' => $_POST['email'],
        'telp' => $_POST['telp']
    ];

    if ($_POST['aksi'] == 'add') {
        $proses->addMahasiswa($data);
    } else if ($_POST['aksi'] == 'edit') {
        $id = $_POST['id'];
        $proses->updateMahasiswa($id, $data);
    }

    header("Location: index.php");
    exit();
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $proses->deleteMahasiswa($id);
    header("Location: index.php");
    exit();
}
?>